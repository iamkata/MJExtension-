//
//  ViewController.m
//  MJExtension-笔记
//
//  Created by 徐金城 on 2020/9/11.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import "ViewController.h"
#import "User.h"
#import "MJExtension.h"
#import "Student.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    [self test1];
    [self test2];
}

- (void)test1 {
    //ViewController.m
    NSDictionary *dict = @{
                           @"name" : @"Jack",
                           @"icon" : @"lufy.png",
                           @"age" : @20,
                           @"height" : @"1.55",
                           @"money" : @100.9
                           };

    // JSON -> User
    User *user = [User mj_objectWithKeyValues:dict];

    NSLog(@"name=%@, icon=%@, age=%u, height=%@, money=%@", user.name, user.icon, user.age, user.height, user.money);
}

- (void)test2 {
    NSDictionary *dict = @{
    @"id" : @"20",
    @"description" : @"kids",
    @"name" : @{
            @"newName" : @"lufy",
            @"oldName" : @"kitty",
            @"info" : @[
                    @"test-data",
                    @{
                        @"nameChangedTime" : @"2013-08"
                        }
                    ]
            },
    @"other" : @{
            @"bag" : @{
                    @"name" : @"a red bag",
                    @"price" : @100.7
                    }
            }
    };
    
    // JSON -> Student
    Student *stu = [Student mj_objectWithKeyValues:dict];
    
    // Printing
    NSLog(@"ID=%@, desc=%@, oldName=%@, nowName=%@, nameChangedTime=%@",
          stu.ID, stu.desc, stu.oldName, stu.nowName, stu.nameChangedTime);
    // ID=20, desc=kids, oldName=kitty, nowName=lufy, nameChangedTime=2013-08

    NSLog(@"bagName=%@, bagPrice=%f", stu.bag.name, stu.bag.price);
    // bagName=a red bag, bagPrice=100.700000
}

@end
