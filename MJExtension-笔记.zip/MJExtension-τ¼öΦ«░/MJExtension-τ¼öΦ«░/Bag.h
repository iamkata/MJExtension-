//
//  Bag.h
//  MJExtension-笔记
//
//  Created by 徐金城 on 2020/9/14.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//Bag.h
@interface Bag : NSObject

@property (nonatomic, copy)NSString *name;
@property (nonatomic, assign)double price;

@end

NS_ASSUME_NONNULL_END
