//
//  MJFoundation.h
//  MJExtensionExample
//
//  Created by MJ Lee on 14/7/16.
//  Copyright (c) 2014年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJFoundation : NSObject

//判断一个类是否是foundation类及其子类
+ (BOOL)isClassFromFoundation:(Class)c;
//判断属性是否是协议里面定义的
+ (BOOL)isFromNSObjectProtocolProperty:(NSString *)propertyName;

@end



