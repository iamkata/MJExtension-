//
//  Student.h
//  MJExtension-笔记
//
//  Created by 徐金城 on 2020/9/14.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Bag.h"
#import "MJExtension.h"

NS_ASSUME_NONNULL_BEGIN

//Student.h
@interface Student : NSObject <MJKeyValue>

@property (nonatomic, copy)NSString *ID;
@property (nonatomic, copy)NSString *desc;
@property (nonatomic, copy)NSString *nowName;
@property (nonatomic, copy)NSString *oldName;
@property (nonatomic, copy)NSString *nameChangedTime;
@property (nonatomic, strong)Bag *bag;

@end

NS_ASSUME_NONNULL_END
