//
//  Student.m
//  MJExtension-笔记
//
//  Created by 徐金城 on 2020/9/14.
//  Copyright © 2020 xujincheng. All rights reserved.
//

#import "Student.h"

@implementation Student

//Student.m
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"ID" : @"id",
             @"desc" : @"description",
             @"oldName" : @"name.oldName",
             @"nowName" : @"name.newName",
             @"nameChangedTime" : @"name.info[1].nameChangedTime",
             @"bag" : @"other.bag"
             };
}


@end
